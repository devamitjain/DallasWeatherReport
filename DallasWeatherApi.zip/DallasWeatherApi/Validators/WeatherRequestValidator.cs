﻿using DallasWeatherApi.Models;
using FluentValidation;

namespace DallasWeatherApi.Validators
{
    /// <summary>
    /// Validator for WeatherRequest (future expansion).
    /// Currently validates a single date request.
    /// </summary>
    public class WeatherRequestValidator : AbstractValidator<WeatherRequest>
    {
        public WeatherRequestValidator()
        {
            RuleFor(x => x.Date)
                .NotEmpty().WithMessage("Date is required.")
                .Must(BeAValidDate).WithMessage("Date must be a valid date.");
        }

        private bool BeAValidDate(DateTime date)
        {
            return date.Year > 1900 && date.Year < 2100;
        }
    }
}
