﻿using DallasWeatherApi.Models;
using System.Net;
using System.Text.Json;

namespace DallasWeatherApi.Middleware
{
    /// <summary>
    /// Global error handling middleware.
    /// Catches all unhandled exceptions and returns a clean JSON error response.
    /// </summary>
    public class ErrorHandlingMiddleware : IMiddleware
    {
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            var errorId = Guid.NewGuid().ToString();

            var errorResponse = new ErrorResponse
            {
                errorId = errorId,
                message = exception.Message,
                detail = exception.InnerException?.Message,
                path = context.Request.Path,
                timestamp = DateTime.UtcNow
            };

            var json = JsonSerializer.Serialize(errorResponse);

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            return context.Response.WriteAsync(json);
        }
    }
}
