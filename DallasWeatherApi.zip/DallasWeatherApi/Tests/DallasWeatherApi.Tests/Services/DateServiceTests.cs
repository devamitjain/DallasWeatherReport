﻿using DallasWeatherApi.Services;
using NUnit.Framework;
using System;
using System.Linq;

namespace DallasWeatherApi.Tests.Services
{
    public class DateServiceTests
    {
        private DateService _service = null!;

        [SetUp]
        public void Setup()
        {
            _service = new DateService();
        }

        [Test]
        public void ParseDates_ValidDates_ReturnsParsedList()
        {
            var input = new[] { "2024-10-01", "2024-10-02" };

            var result = _service.ParseDates(input).ToList();

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(new DateTime(2024, 10, 1), result[0]);
            Assert.AreEqual(new DateTime(2024, 10, 2), result[1]);
        }

        [Test]
        public void ParseDates_InvalidDates_IgnoresInvalid()
        {
            var input = new[] { "invalid", "2024-10-03" };

            var result = _service.ParseDates(input).ToList();

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(new DateTime(2024, 10, 3), result[0]);
        }
    }
}
