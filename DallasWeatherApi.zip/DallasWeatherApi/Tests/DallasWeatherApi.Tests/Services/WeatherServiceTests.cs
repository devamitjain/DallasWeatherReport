﻿using DallasWeatherApi.Models;
using DallasWeatherApi.Services;
using Microsoft.Extensions.Options;
using NUnit.Framework;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace DallasWeatherApi.Tests.Services
{
    public class WeatherServiceTests
    {
        private WeatherService _service = null!;
        private HttpClient _httpClient = null!;
        private WeatherApiOptions _options = null!;

        [SetUp]
        public void Setup()
        {
            var handler = new FakeHttpMessageHandler();
            _httpClient = new HttpClient(handler);

            _options = new WeatherApiOptions
            {
                BaseUrl = "https://fake-weather-api.com",
                Latitude = 32.7,
                Longitude = -96.8,
                Timezone = "America/Chicago"
            };

            _service = new WeatherService(_httpClient, Options.Create(_options));
        }

        [Test]
        public async Task GetWeatherForDateAsync_ReturnsDailyWeatherValues()
        {
            var date = new DateTime(2024, 10, 1);

            var result = await _service.GetWeatherForDateAsync(date);

            Assert.IsNotNull(result);
            Assert.AreEqual(date, result.date);

            Assert.AreEqual(18.5, result.minTemperatureC);
            Assert.AreEqual(27.3, result.maxTemperatureC);
            Assert.AreEqual(2.1, result.precipitationMm);
        }

        [Test]
        public void GetWeatherForDateAsync_ThrowsException_ReturnsError()
        {
            var handler = new FakeErrorHttpMessageHandler();
            var httpClient = new HttpClient(handler);

            var service = new WeatherService(httpClient, Options.Create(_options));

            Assert.ThrowsAsync<HttpRequestException>(async () =>
            {
                await service.GetWeatherForDateAsync(new DateTime(2024, 10, 1));
            });
        }

        private class FakeErrorHttpMessageHandler : HttpMessageHandler
        {
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent("Server error")
                });
            }
        }

        private class FakeHttpMessageHandler : HttpMessageHandler
        {
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                var json = @"{
                    ""daily"": {
                        ""temperature_2m_min"": [18.5],
                        ""temperature_2m_max"": [27.3],
                        ""precipitation_sum"": [2.1]
                    }
                }";

                var response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(json)
                };

                return Task.FromResult(response);
            }
        }
    }
}
