﻿using DallasWeatherApi.Services;
using NUnit.Framework;
using System.IO;
using System.Threading.Tasks;

namespace DallasWeatherApi.Tests.Services
{
    public class FileStorageServiceTests
    {
        private FileStorageService _service = null!;
        private string _tempFile = null!;

        [SetUp]
        public void Setup()
        {
            _service = new FileStorageService();
            _tempFile = Path.GetTempFileName();
        }

        [Test]
        public async Task WriteTextAsync_WritesContent()
        {
            await _service.WriteTextAsync(_tempFile, "hello world");

            var content = await File.ReadAllTextAsync(_tempFile);

            Assert.AreEqual("hello world", content);
        }

        [Test]
        public async Task ReadAllLinesAsync_ReadsLines()
        {
            await File.WriteAllLinesAsync(_tempFile, new[] { "a", "b" });

            var lines = await _service.ReadAllLinesAsync(_tempFile);

            Assert.AreEqual(2, lines.Length);
            Assert.AreEqual("a", lines[0]);
            Assert.AreEqual("b", lines[1]);
        }
    }
}
