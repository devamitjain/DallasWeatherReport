﻿using DallasWeatherApi.Models;
using DallasWeatherApi.Services;
using Microsoft.Extensions.Options;

namespace DallasWeatherApi.BackgroundWorkers
{
    /// <summary>
    /// Background worker that runs once per day at a configured hour.
    /// Disabled by default (see Program.cs).
    /// </summary>
    public class WeatherBackgroundWorker : BackgroundService
    {
        private readonly ILogger<WeatherBackgroundWorker> _logger;
        private readonly IWeatherService _weatherService;
        private readonly IFileStorageService _fileStorageService;
        private readonly IDateService _dateService;
        private readonly StorageOptions _storageOptions;
        private readonly BackgroundWorkerOptions _workerOptions;

        public WeatherBackgroundWorker(
            ILogger<WeatherBackgroundWorker> logger,
            IWeatherService weatherService,
            IFileStorageService fileStorageService,
            IDateService dateService,
            IOptions<StorageOptions> storageOptions,
            IOptions<BackgroundWorkerOptions> workerOptions)
        {
            _logger = logger;
            _weatherService = weatherService;
            _fileStorageService = fileStorageService;
            _dateService = dateService;
            _storageOptions = storageOptions.Value;
            _workerOptions = workerOptions.Value;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            if (!_workerOptions.Enabled)
            {
                _logger.LogInformation("WeatherBackgroundWorker is disabled in configuration.");
                return;
            }

            _logger.LogInformation("WeatherBackgroundWorker started.");

            while (!stoppingToken.IsCancellationRequested)
            {
                var now = DateTime.Now;

                if (now.Hour == _workerOptions.RunAtHour)
                {
                    try
                    {
                        await RunWeatherJobAsync();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error running daily weather job.");
                    }

                    // Sleep for 1 hour to avoid multiple runs within the same hour
                    await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
                }

                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }

        private async Task RunWeatherJobAsync()
        {
            _logger.LogInformation("Running daily weather job...");

            var datesFilePath = Path.Combine(AppContext.BaseDirectory, _storageOptions.DatesFile);
            var weatherDataFolderPath = Path.Combine(AppContext.BaseDirectory, _storageOptions.WeatherDataFolder);

            if (!File.Exists(datesFilePath))
            {
                _logger.LogWarning("Dates file not found: {path}", datesFilePath);
                return;
            }

            if (!Directory.Exists(weatherDataFolderPath))
            {
                Directory.CreateDirectory(weatherDataFolderPath);
            }

            var dateStrings = await _fileStorageService.ReadAllLinesAsync(datesFilePath);
            var parsedDates = _dateService.ParseDates(dateStrings);

            foreach (var date in parsedDates)
            {
                var weather = await _weatherService.GetWeatherForDateAsync(date);

                var fileName = $"{date:yyyy-MM-dd}.json";
                var filePath = Path.Combine(weatherDataFolderPath, fileName);

                await _fileStorageService.WriteTextAsync(filePath, weather.ToJson());

                _logger.LogInformation("Saved weather file: {file}", filePath);
            }

            _logger.LogInformation("Daily weather job completed.");
        }
    }
}
