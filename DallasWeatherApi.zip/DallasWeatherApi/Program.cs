﻿using DallasWeatherApi.Middleware;
using DallasWeatherApi.Services;
using DallasWeatherApi.Validators;
using DallasWeatherApi.BackgroundWorkers;
using DallasWeatherApi.Models;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Extensions.Http;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Serilog configuration
builder.Host.UseSerilog((context, services, configuration) =>
{
    configuration
        .ReadFrom.Configuration(context.Configuration)
        .ReadFrom.Services(services);
});
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngular",
        policy =>
        {
            policy.WithOrigins("http://localhost:4200")
                  .AllowAnyHeader()
                  .AllowAnyMethod()
                  .AllowCredentials();
        });
});
// Add services to the container
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = null;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configuration binding
builder.Services.Configure<WeatherApiOptions>(
    builder.Configuration.GetSection("WeatherApi"));
builder.Services.Configure<StorageOptions>(
    builder.Configuration.GetSection("Storage"));
builder.Services.Configure<BackgroundWorkerOptions>(
    builder.Configuration.GetSection("BackgroundWorker"));

// HttpClient with Polly retry
builder.Services.AddHttpClient<IWeatherService, WeatherService>()
    .AddPolicyHandler(GetRetryPolicy());

// File storage service
builder.Services.AddSingleton<IFileStorageService, FileStorageService>();

// Date service
builder.Services.AddSingleton<IDateService, DateService>();

// FluentValidation
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<WeatherRequestValidator>();

// Response caching
builder.Services.AddResponseCaching();

// Background worker (disabled by config; registration commented out)
// builder.Services.AddHostedService<WeatherBackgroundWorker>();

// Error handling middleware
builder.Services.AddSingleton<ErrorHandlingMiddleware>();

var app = builder.Build();

// Middleware pipeline
app.UseSerilogRequestLogging();

app.UseMiddleware<ErrorHandlingMiddleware>();
app.UseCors("AllowAngular");
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseResponseCaching();

app.MapControllers();

app.Run();

static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
{
    return HttpPolicyExtensions
        .HandleTransientHttpError()
        .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
}
