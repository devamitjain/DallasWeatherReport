﻿namespace DallasWeatherApi.Models
{
    public class WeatherApiOptions
    {
        public string BaseUrl { get; set; } = string.Empty;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Timezone { get; set; } = string.Empty;
    }
}
