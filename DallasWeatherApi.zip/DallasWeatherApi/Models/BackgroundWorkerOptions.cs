﻿namespace DallasWeatherApi.Models
{
    public class BackgroundWorkerOptions
    {
        public bool Enabled { get; set; }
        public int RunAtHour { get; set; } = 2;
    }
}
