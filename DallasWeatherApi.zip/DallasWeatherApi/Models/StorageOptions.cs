﻿namespace DallasWeatherApi.Models
{
    public class StorageOptions
    {
        public string WeatherDataFolder { get; set; } = "weather-data";
        public string DatesFile { get; set; } = "dates.txt";
    }
}
