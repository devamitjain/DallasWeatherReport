﻿namespace DallasWeatherApi.Models
{
    public class OpenMeteoResponse
    {
        public DailyData? Daily { get; set; }
    }

    public class DailyData
    {
        public double[]? Temperature_2m_min { get; set; }
        public double[]? Temperature_2m_max { get; set; }
        public double[]? Precipitation_sum { get; set; }
    }
}
