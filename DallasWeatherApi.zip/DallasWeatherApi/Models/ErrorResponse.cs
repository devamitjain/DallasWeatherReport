﻿namespace DallasWeatherApi.Models
{
    public class ErrorResponse
    {
        public string errorId { get; set; } = string.Empty;
        public dynamic? message { get; set; } = string.Empty;
        public string? detail { get; set; }
        public string path { get; set; } = string.Empty;
        public DateTime timestamp { get; set; }
    }
}