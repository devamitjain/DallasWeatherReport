﻿using System.Text.Json;

namespace DallasWeatherApi.Models
{
    public class WeatherResult
    {
        public DateTime date { get; set; }
        public double? minTemperatureC { get; set; }
        public double? maxTemperatureC { get; set; }
        public double? precipitationMm { get; set; }
        public ErrorResponse? errorMessage { get; set; }
        public string ToJson()
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true
            };
            return JsonSerializer.Serialize(this, options);
        }
    }
}
