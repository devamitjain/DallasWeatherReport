﻿namespace DallasWeatherApi.Models
{
    public class WeatherRequest
    {
        public DateTime Date { get; set; }
    }
}
