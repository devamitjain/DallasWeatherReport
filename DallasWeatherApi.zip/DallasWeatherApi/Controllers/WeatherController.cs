﻿using DallasWeatherApi.Models;
using DallasWeatherApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DallasWeatherApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherController : ControllerBase
    {
        private readonly IWeatherService _weatherService;
        private readonly IFileStorageService _fileStorageService;
        private readonly IDateService _dateService;
        private readonly StorageOptions _storageOptions;

        public WeatherController(
            IWeatherService weatherService,
            IFileStorageService fileStorageService,
            IDateService dateService,
            IOptions<StorageOptions> storageOptions)
        {
            _weatherService = weatherService;
            _fileStorageService = fileStorageService;
            _dateService = dateService;
            _storageOptions = storageOptions.Value;
        }

        /// <summary>
        /// Gets weather data for all dates listed in dates.txt.
        /// </summary>
        /// <returns>List of weather results.</returns>
        [HttpGet]
        [ResponseCache(Duration = 60)]
        public async Task<ActionResult<IEnumerable<WeatherResult>>> Get()
        {
            var datesFilePath = Path.Combine(AppContext.BaseDirectory, _storageOptions.DatesFile);
            var weatherDataFolderPath = Path.Combine(AppContext.BaseDirectory, _storageOptions.WeatherDataFolder);

            if (!System.IO.File.Exists(datesFilePath))
            {
                return NotFound($"Dates file not found at path: {datesFilePath}");
            }

            if (!Directory.Exists(weatherDataFolderPath))
            {
                Directory.CreateDirectory(weatherDataFolderPath);
            }

            var dateStrings = await _fileStorageService.ReadAllLinesAsync(datesFilePath);
            var parsedDates = _dateService.ParseDates(dateStrings);

            var results = new List<WeatherResult>();

            foreach (var date in parsedDates)
            {
                var weather = await _weatherService.GetWeatherForDateAsync(date);
                if (weather.errorMessage != null)
                {
                    var fileName = $"{date:yyyy-MM-dd}.json";
                    var filePath = Path.Combine(weatherDataFolderPath, fileName);

                    await _fileStorageService.WriteTextAsync(filePath, weather.ToJson());
                }
                results.Add(weather);
            }

            return Ok(results);
        }
    }
}
