﻿namespace DallasWeatherApi.Services
{
    public interface IFileStorageService
    {
        Task<string[]> ReadAllLinesAsync(string path);
        Task WriteTextAsync(string path, string content);
    }
}
