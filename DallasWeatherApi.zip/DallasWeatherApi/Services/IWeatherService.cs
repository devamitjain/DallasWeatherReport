﻿using DallasWeatherApi.Models;

namespace DallasWeatherApi.Services
{
    public interface IWeatherService
    {
        Task<WeatherResult> GetWeatherForDateAsync(DateTime date);
    }
}
