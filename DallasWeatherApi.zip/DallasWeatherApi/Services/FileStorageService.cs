﻿namespace DallasWeatherApi.Services
{
    public class FileStorageService : IFileStorageService
    {
        public async Task<string[]> ReadAllLinesAsync(string path)
        {
            return await System.IO.File.ReadAllLinesAsync(path);
        }

        public async Task WriteTextAsync(string path, string content)
        {
            var directory = System.IO.Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory) && !System.IO.Directory.Exists(directory))
            {
                System.IO.Directory.CreateDirectory(directory);
            }

            await System.IO.File.WriteAllTextAsync(path, content);
        }
    }
}
