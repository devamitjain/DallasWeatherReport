﻿using DallasWeatherApi.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Polly;
using System.Net.Http.Json;
using System.Text.Json.Serialization;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DallasWeatherApi.Services
{
    public class WeatherService : IWeatherService
    {
        private readonly HttpClient _httpClient;
        private readonly WeatherApiOptions _options;

        public WeatherService(HttpClient httpClient, IOptions<WeatherApiOptions> options)
        {
            _httpClient = httpClient;
            _options = options.Value;
        }

        public async Task<WeatherResult> GetWeatherForDateAsync(DateTime date)
        {
            var url = $"{_options.BaseUrl}?latitude={_options.Latitude}&longitude={_options.Longitude}&daily=temperature_2m_min,temperature_2m_max,precipitation_sum&timezone={_options.Timezone}&start_date={date:yyyy-MM-dd}&end_date={date:yyyy-MM-dd}";
            HttpResponseMessage? response=null;
            try
            {
                response = await _httpClient.GetAsync(url);

                if (response.StatusCode!= System.Net.HttpStatusCode.OK) { 
            
                        var errorId = Guid.NewGuid().ToString();
                        return new WeatherResult
                        {
                            date = date,
                            minTemperatureC = null,
                            maxTemperatureC = null,
                            precipitationMm = null,

                            errorMessage = new ErrorResponse
                            {

                                errorId = errorId,
                                message = JsonConvert.DeserializeObject<dynamic>(response.Content.ReadAsStringAsync().Result),
                                detail = JsonConvert.DeserializeObject<dynamic>(response.Content.ReadAsStringAsync().Result)?.reason?.Value,
                                path = url,
                                timestamp = DateTime.UtcNow
                            }
                        };
                    }
                response?.EnsureSuccessStatusCode();

                var apiResponse = await response.Content.ReadFromJsonAsync<OpenMeteoResponse>();

                var daily = apiResponse?.Daily;

                return new WeatherResult
                {
                    date = date,
                    minTemperatureC = daily?.Temperature_2m_min?.FirstOrDefault(),
                    maxTemperatureC = daily?.Temperature_2m_max?.FirstOrDefault(),
                    precipitationMm = daily?.Precipitation_sum?.FirstOrDefault()
                };
            }
            catch (Exception ex) { throw; }
        }
    }
}
