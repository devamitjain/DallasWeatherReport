﻿namespace DallasWeatherApi.Services
{
    public interface IDateService
    {
        IEnumerable<DateTime> ParseDates(IEnumerable<string> dateStrings);
    }
}
