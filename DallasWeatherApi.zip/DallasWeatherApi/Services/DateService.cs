﻿namespace DallasWeatherApi.Services
{
    public class DateService : IDateService
    {
        public IEnumerable<DateTime> ParseDates(IEnumerable<string> dateStrings)
        {
            var result = new List<DateTime>();

            foreach (var s in dateStrings)
            {
                if (DateTime.TryParse(s, out var dt))
                {
                    result.Add(dt.Date);
                }
            }

            return result;
        }
    }
}
